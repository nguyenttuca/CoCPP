# Bộ 10 test cực mạnh — I. Bài tập 9 (Đếm ước của $C_N^K$)

Mỗi test gồm 2 file: `testK.txt` (input, có thể nhiều dòng $(N, K)$ vì đề yêu cầu đọc đến hết EOF) và `testK.ans` (đáp án đúng, mỗi dòng tương ứng 1 dòng input).

| Test | Số dòng | Đặc điểm |
|---|---|---|
| 1 | 3 | Ví dụ gốc trong đề bài (sanity check bắt buộc phải đúng) |
| 2 | 14 | $K=0$ hoặc $K=N$ → $C_N^K=1$, số ước luôn là 1 (trường hợp biên tầm thường) |
| 3 | 499 | $K=1$ với mọi $N$ từ 1 đến 499 → $C_N^1=N$, kết quả bằng đúng số ước của $N$ |
| 4 | 340 | $N=499$ (max) cố định, quét mọi $K$ **an toàn** — test hiệu năng khi tính lại Legendre nhiều lần với $N$ lớn |
| 5 | 30 | 30 cặp có số ước **gần sát giới hạn $2^{63}-1$ nhất** có thể tìm được trong miền hợp lệ — test overflow trực diện |
| 6 | 50000 | Toàn bộ 50000 dòng đều là `(0, 0)` — test tốc độ đọc/ghi I/O với số lượng dòng cực lớn |
| 7 | 443 | $K = \lfloor N/2 \rfloor$ với mọi $N$ hợp lệ — vị trí trung tâm tổ hợp, thường cho số ước lớn |
| 8 | 100000 | Ngẫu nhiên 100000 dòng trải khắp không gian $(N,K)$ hợp lệ — test tổng hợp số lượng query lớn nhất |
| 9 | 500 | $N$ tăng dần từ 0→499, mỗi dòng $K$ ngẫu nhiên (đảm bảo an toàn) |
| 10 | 437 | Hỗn hợp: các trường hợp biên (N=0,1; K=0,N), 20 cặp gần giới hạn 64-bit, 200 cặp ngẫu nhiên, và toàn bộ cặp với N nhỏ (0–19) |

## ⚠️ Phát hiện quan trọng khi kiểm chứng đề bài

Đề bài nói *"Dữ liệu vào đảm bảo kết quả không vượt quá kiểu số nguyên 64 bit"*, nhưng qua khảo sát **toàn bộ** không gian $(N,K)$ với $0 \le K \le N < 500$, có tới:

- **5297 cặp** cho số ước vượt quá `long long` có dấu ($2^{63}-1 \approx 9.22 \times 10^{18}$)
- **3695 cặp** vượt quá cả `unsigned long long` ($2^{64}-1 \approx 1.84 \times 10^{19}$)
- Giá trị lớn nhất toàn miền: $N=498, K=229$ cho **996124179980315787264** ước (~$9.96 \times 10^{20}$, vượt xa 64-bit)

→ Điều này có nghĩa lời đảm bảo của đề **chỉ áp dụng cho các test thực tế sẽ được chấm**, không phải với mọi $(N,K)$ hợp lệ theo ràng buộc $N,K$. Vì vậy, **toàn bộ 10 test trong bộ này đã được lọc để đảm bảo mọi kết quả đều $\le 2^{63}-1$**, tránh tự mâu thuẫn với đề bài. Test 5 được thiết kế riêng để đưa giá trị tiệm cận sát giới hạn này nhất — nếu code dùng nhầm kiểu `int` hoặc `unsigned int` (32-bit) sẽ lộ ra ngay, và nếu dùng `long long` nhưng tính sai công thức Legendre (ví dụ quên `break` khi $p^i$ vượt N, gây vòng lặp vô hạn hoặc overflow trung gian) cũng sẽ bị phát hiện.

## Cách sinh & kiểm chứng

- **Thuật toán chuẩn**: sàng số nguyên tố đến 499, dùng công thức Legendre tính số mũ của từng số nguyên tố $p$ trong $N!/(K! \cdot (N-K)!)$, rồi số ước $= \prod (e_i + 1)$. Độ phức tạp mỗi truy vấn $O(\pi(N))$, rất nhanh.
- Đáp án đã được đối chiếu chéo bằng **3 cách tính độc lập**:
  1. Cache Legendre trong script sinh test (Python)
  2. Một hàm Legendre viết lại hoàn toàn từ đầu, độc lập (`legendre_v2`)
  3. Với $N \le 60$: tính trực tiếp `math.comb(N,K)` rồi phân tích thừa số nguyên tố bằng trial division
- Solution C++ mẫu (`sol.cpp`, dùng `unsigned long long`) chạy trên cả 10 test cho kết quả khớp 100% với 3 oracle trên, tổng cộng hơn **152000 dòng dữ liệu** được kiểm chứng không sai lệch.
- Thời gian chạy: test nặng nhất (100000 dòng) chỉ mất khoảng 0.5 giây, an toàn so với giới hạn 2 giây của đề.
- Mọi dòng input đều được validate: đúng format `N K`, thoả `0 ≤ K ≤ N < 500`.

## Về ví dụ 1 trong đề gốc

Ví dụ 1 (`5 1`, `6 3`, `10 4` → `2, 6, 16`) đã được xác nhận đúng và dùng làm test 1 trong bộ này.
