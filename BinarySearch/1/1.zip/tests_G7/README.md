# Bộ 10 test cực mạnh — G. Bài tập 7

Mỗi test gồm 2 file: `testK.txt` (input) và `testK.ans` (đáp án đúng, đã kiểm chứng chéo bằng brute-force + stress test hàng nghìn case ngẫu nhiên nhỏ).

| Test | N | M | Đặc điểm | Đáp án |
|---|---|---|---|---|
| 1 | 1 | 1 | Biên nhỏ nhất tuyệt đối (N=M=1) | 0 |
| 2 | 1 | 300000 | N=1, M lớn nhất | 0 |
| 3 | 300000 | 1 | M=1 (mọi giá trị bắt buộc =0), N lớn nhất | 0 |
| 4 | 300000 | 300000 | Dãy đã không giảm sẵn (best case) | 0 |
| 5 | 300000 | 300000 | Dãy giảm dần tuyệt đối `M-1, M-2, ..., 0` (worst-case kinh điển) | 150000 |
| 6 | 300000 | 300000 | Tất cả phần tử bằng nhau | 0 |
| 7 | 300000 | 300000 | Pattern răng cưa (sawtooth): `M-1, 0, M/2` lặp lại — nhiều lần wrap liên tiếp | 150000 |
| 8 | 300000 | 300000 | Xen kẽ `0, M-1, 0, M-1, ...` — kiểm tra wrap biên chính xác | 1 |
| 9 | 300000 | 2 | N lớn, M cực nhỏ (M=2) — rất nhiều giá trị trùng lặp | 1 |
| 10 | 300000 | 300000 | Random với cụm tăng dần xen kẽ "nhảy" đột ngột (2% xác suất) — mô phỏng dữ liệu thực tế pha trộn | 294774 |

## Cách sinh & kiểm chứng

- **Đáp án** được tính bằng thuật toán chuẩn: binary search trên số thao tác `x` (0 ≤ x ≤ M−1), kiểm tra tính khả thi bằng greedy trái→phải trên "cung giá trị" `{(A_i + c) mod M : c = 0..x}` của từng phần tử — độ phức tạp O(N log M).
- Thuật toán này đã được **stress test chéo** với hai bản brute-force độc lập (một bản duyệt vét cạn toàn bộ tổ hợp cho N,M ≤ 6, một bản duyệt theo x cho N,M ≤ 5) trên hơn 3500 test ngẫu nhiên nhỏ — **không phát hiện sai lệch nào**.
- Mọi input đều thoả ràng buộc đề bài: `1 ≤ N, M ≤ 300000` và `0 ≤ A_i < M`.
- Thời gian chạy thực tế của solution chuẩn trên từng test đều dưới 0.1 giây (giới hạn đề bài là 2 giây), nên các test đủ lớn để phân biệt thuật toán đúng độ phức tạp với thuật toán chậm hơn (ví dụ O(N·M) hoặc O(N²) sẽ time-out rõ rệt trên test 4–10).

## Lưu ý quan trọng phát hiện được khi kiểm chứng

Một cách tiếp cận sai phổ biến là giả định **phần tử đầu tiên luôn giữ nguyên (c₁ = 0)**. Điều này **sai** — ví dụ với `A = [4, 1], M = 5`: nếu giữ nguyên A₁ = 4 thì cần rất nhiều bước để A₂ đuổi kịp, nhưng nếu cho A₁ "wrap" thành `(4+1) mod 5 = 0` thì chỉ cần 1 thao tác là xong (A₂ = 1 ≥ 0). Vì vậy phần tử đầu tiên cần chọn **giá trị nhỏ nhất có thể đạt được trong cung của nó**, không phải cố định c=0. Test 8 và test 5 trong bộ này được thiết kế để bắt lỗi chính xác kiểu sai lầm này.
